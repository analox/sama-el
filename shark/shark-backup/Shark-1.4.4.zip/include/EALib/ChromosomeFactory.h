
#ifndef _ChromosomeFactory_h_
#define _ChromosomeFactory_h_


#include <EALib/ChromosomeT.h>


Chromosome* CreateChromosome(const char* type);


#endif
