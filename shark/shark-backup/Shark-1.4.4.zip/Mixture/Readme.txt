This library provides classes for the representation and optimization
of mixture density models. A large emphasis is put on various
implementation of the EM algorithm.
This library was originally developped at the Institut fuer
Neuroinformatik, Ruhr-Universitaet Bochum, and released under GPL.
