A collection of different pseudo random number generators.
This library was originally developped at the Institut fuer
Neuroinformatik, Ruhr-Universitaet Bochum, and released under GPL.
