This library provides various classes for e.g. linear classification,
triangularization of matrices, singular value decomposition, linear
discriminant analysis, matrix inversion, etc.
Additionally, some nonlinear optimization methods are included
as BFGS algorithm, line search etc.
This library was originally developped at the Institut fuer
Neuroinformatik, Ruhr-Universitaet Bochum, and released under GPL.
